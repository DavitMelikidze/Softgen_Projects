import React, {useEffect, useState} from 'react';
import api from "../utils/localhost8080Api";
import StudentsList from "../posts/StudentsList";
import {Button, Form, Modal} from "react-bootstrap";

const initialInput = {
id:'',
firstname:'',
lastname:'',
personalNo:'',
email:'',
birthDate:''
}

function TeacherView(props) {

    const [teachers, setTeachers] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [showModalPost, setShowModalPost] = useState(false);
    const [formValues, setFormValues] = useState(initialInput);
    const [curTeacher, setCurTeacher] = useState({});
    const [formValues2, setFormValues2] = useState(initialInput);
    const [getRequestTeacher,setGetRequestTeacher] = useState({});

    async function getTeachers(params) {
        const response = await api.get('/teachers', {params});
        setTeachers(response.data);
    }

    const putTeacherModal = (teacher) => {
        setCurTeacher(teacher)
        setShowModal(true);
    }

    const showPost = () => {
        setShowModalPost(true);
        setFormValues({});
    }

    useEffect(()=>{
        setFormValues(curTeacher);
    },[curTeacher])

    const hideModal = () => {
        setShowModal(false);
        setShowModalPost(false);
    }

    useEffect(() => {
        getTeachers(getRequestTeacher).catch(console.error);
        console.log(getRequestTeacher);
    }, [getRequestTeacher])

    const changeHandler = (e) => {
        const {name, value} = e.target;
        console.log("this is name: ", name);
        setFormValues({...formValues, [name]: value});
    }

    const changeHandler2 = (e) => {
        const {name,value} = e.target;
        if(e.target)
        setFormValues2({...formValues2,[name]:value});
    }

    const onTeacherPutSubmitHandler = (e) => {
        e.preventDefault();
        console.log("we are here");
        if(showModal)
            api.put(`/teachers/${curTeacher.id}`, formValues);
        if(showModalPost)
            api.post('/teachers/',formValues);
        document.location.reload();
        setFormValues({});
        hideModal();
    }

    const onTeacherSubmitHandler = (e)=>{
        e.preventDefault();
        console.log(formValues2);
        setGetRequestTeacher(formValues2);
        document.location.reload();
        setFormValues2({});
    }

    return (
        <div>
            <Form onSubmit={onTeacherSubmitHandler} className="d-flex">

                <Form.Group className="mb-3" controlId="formBasicFirstname">
                    <Form.Label>firstname</Form.Label>
                    <Form.Control name="firstname" value={formValues2.firstname} type="text"
                                  placeholder="Search by firstname" onChange={changeHandler2}/>

                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicLastname">
                    <Form.Label>lastname</Form.Label>
                    <Form.Control value={formValues2.lastname} type="text" name="lastname"
                                  placeholder="search by lastname" onChange={changeHandler2}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicPersonalNo">
                    <Form.Label>personalNo</Form.Label>
                    <Form.Control value={formValues2.personalNo} type="text" name="personalNo"
                                  placeholder="Search by personalNo" onChange={changeHandler2}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>email</Form.Label>
                    <Form.Control value={formValues2.email} type="email" name="email"
                                  placeholder="Search by email" onChange={changeHandler2}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicBirthdate">
                    <Form.Label>birthdate</Form.Label>
                    <Form.Control value={formValues2.birthdate} type="date" name="birthDate"
                                  placeholder="Search by Birthdate" onChange={changeHandler2}/>
                </Form.Group>
                <div/>
                <Button variant="primary" type="submit">
                    Search
                </Button>
            </Form>

            <Button onClick={showPost}>Add new student</Button>
            <StudentsList data={teachers} func={putTeacherModal} title="students list"/>
            <Modal show={showModal || showModalPost} onHide={hideModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Change Teacher info</Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    <Form onSubmit={onTeacherPutSubmitHandler} id="student-put-submit">
                        <Form.Group className="mb-3" controlId="formBasicFirstname">
                            <Form.Label>firstname</Form.Label>
                            <Form.Control name="firstname" value={formValues.firstname} type="text"
                                          placeholder="Enter new firstname" onChange={changeHandler}/>

                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicLastname">
                            <Form.Label>lastname</Form.Label>
                            <Form.Control value={formValues.lastname} type="text" name="lastname"
                                          placeholder="Enter new lastname" onChange={changeHandler}/>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPersonalNo">
                            <Form.Label>personalNo</Form.Label>
                            <Form.Control value={formValues.personalNo} type="text" name="personalNo"
                                          placeholder="Enter new personalNo" onChange={changeHandler}/>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>email</Form.Label>
                            <Form.Control value={formValues.email} type="email" name="email"
                                          placeholder="Enter new email" onChange={changeHandler}/>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicBirthdate">
                            <Form.Label>birthdate</Form.Label>
                            <Form.Control value={formValues.birthDate} type="date" name="birthDate"
                                          placeholder="Enter new Birthdate" onChange={changeHandler}/>
                        </Form.Group>
                        {
                            showModal ? (
                                <Button variant="primary" type="submit">
                                    save Changes
                                </Button> ) : <></>
                        }
                        {
                            showModalPost ? (
                                <Button variant="primary" type="submit">
                                    add student
                                </Button> ) : <></>
                        }
                    </Form>
                </Modal.Body>
            </Modal>
        </div>
    );
}

export default TeacherView;