import React, {useEffect, useState} from 'react';
import api from "../utils/localhost8080Api";
import StudentsList from "../posts/StudentsList";
import {Button, Form, Modal} from "react-bootstrap";

const initialInput = {
    id:'',
    firstname:'',
    lastname:'',
    personalNo:'',
    email:'',
    birthDate:''
}

function StudentView(props) {

    const [students, setStudents] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [showModalPost, setShowModalPost] = useState(false);
    const [formValues, setFormValues] = useState(initialInput);
    const [curStudent, setCurStudent] = useState({});
    const [formValues2, setFormValues2] = useState(initialInput);
    const [getRequestStudent,setGetRequestStudent] = useState({});

    async function getStudents(params) {
        const response = await api.get('/students', {params});
        setStudents(response.data);
    }

    const putStudentModal = (student) => {
        setCurStudent(student)
        setShowModal(true);
    }

    const showPost = () => {
        setShowModalPost(true);
        setFormValues({});
    }

    useEffect(()=>{
        setFormValues(curStudent);
    },[curStudent])

    const hideModal = () => {
        setShowModal(false);
        setShowModalPost(false);
    }

    useEffect(() => {
        getStudents(getRequestStudent).catch(console.error);
        console.log(getRequestStudent);
    }, [getRequestStudent])

    const changeHandler = (e) => {
        const {name, value} = e.target;
        console.log("this is name: ", name);
        setFormValues({...formValues, [name]: value});
    }

    const changeHandler2 = (e) => {
        const {name,value} = e.target;
        setFormValues2({...formValues2,[name]:value});
    }

    const onStudentPutSubmitHandler = (e) => {
        //e.preventDefault();
        console.log("we are here");
        if(showModal)
            api.put(`/students/${curStudent.id}`, formValues);
        if(showModalPost)
            api.post('/students/',formValues);
        //document.location.reload();
        hideModal();
    }

    const onSearchSubmitHandler = (e)=>{
        e.preventDefault();
        console.log(formValues2);
        setGetRequestStudent(formValues2);
    }

    return (
        <div>
            <Form onSubmit={onSearchSubmitHandler} className="d-flex">

                <Form.Group className="mb-3" controlId="formBasicFirstname">
                    <Form.Label>firstname</Form.Label>
                    <Form.Control name="firstname" value={formValues2.firstname} type="text"
                                  placeholder="Search by firstname" onChange={changeHandler2}/>

                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicLastname">
                    <Form.Label>lastname</Form.Label>
                    <Form.Control value={formValues2.lastname} type="text" name="lastname"
                                  placeholder="search by lastname" onChange={changeHandler2}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicPersonalNo">
                    <Form.Label>personalNo</Form.Label>
                    <Form.Control value={formValues2.personalNo} type="text" name="personalNo"
                                  placeholder="Search by personalNo" onChange={changeHandler2}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>email</Form.Label>
                    <Form.Control value={formValues2.email} type="email" name="email"
                                  placeholder="Search by email" onChange={changeHandler2}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicBirthdate">
                    <Form.Label>birthdate</Form.Label>
                    <Form.Control value={formValues2.birthdate} type="date" name="birthDate"
                                  placeholder="Search by Birthdate" onChange={changeHandler2}/>
                </Form.Group>
                <div/>
                <Button variant="primary" type="submit">
                    Search
                </Button>
            </Form>

            <Button onClick={showPost}>Add new student</Button>
            <StudentsList data={students} func={putStudentModal} title="students list"/>
            <Modal show={showModal || showModalPost} onHide={hideModal}>
                <Modal.Header closeButton>
                    <Modal.Title>Change student info</Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    <Form onSubmit={onStudentPutSubmitHandler} id="student-put-submit">
                        <Form.Group className="mb-3" controlId="formBasicFirstname">
                            <Form.Label>firstname</Form.Label>
                            <Form.Control name="firstname" value={formValues.firstname} type="text"
                                          placeholder="Enter new firstname" onChange={changeHandler}/>

                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicLastname">
                            <Form.Label>lastname</Form.Label>
                            <Form.Control value={formValues.lastname} type="text" name="lastname"
                                          placeholder="Enter new lastname" onChange={changeHandler}/>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPersonalNo">
                            <Form.Label>personalNo</Form.Label>
                            <Form.Control value={formValues.personalNo} type="text" name="personalNo"
                                          placeholder="Enter new personalNo" onChange={changeHandler}/>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>email</Form.Label>
                            <Form.Control value={formValues.email} type="email" name="email"
                                          placeholder="Enter new email" onChange={changeHandler}/>
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicBirthdate">
                            <Form.Label>birthdate</Form.Label>
                            <Form.Control value={formValues.birthDate} type="date" name="birthDate"
                                          placeholder="Enter new Birthdate" onChange={changeHandler}/>
                        </Form.Group>
                        {
                            showModal ? (
                                <Button variant="primary" type="submit">
                                    save Changes
                                </Button> ) : <></>
                        }
                        {
                            showModalPost ? (
                                <Button variant="primary" type="submit">
                                    add student
                                </Button> ) : <></>
                        }
                    </Form>
                </Modal.Body>
            </Modal>
        </div>
    );
}

export default StudentView;