import {Link, Outlet} from "react-router-dom";
import {Container, Nav} from "react-bootstrap";

function App() {
  return (
  <>
    <Container fluid>
      <header className="border border-1">
        <Nav
            activeKey="/"
            onSelect={(selectedKey) => alert(`selected ${selectedKey}`)}
        >
          <Nav.Item>
            <Nav.Link as={Link} to={"/"}>Home</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link as={Link} to="/students">Students</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link as={Link} to="/teachers">Teachers</Nav.Link>
          </Nav.Item>
        </Nav>
      </header>
      <Outlet/>

      <footer className="p-5 bg-black bg-opacity-10 text-center">
        Footer
      </footer>
    </Container>
  </>
  );
}

export default App;
