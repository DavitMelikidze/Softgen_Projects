import React, {useEffect, useState} from 'react';
import {Button, Table} from "react-bootstrap";
import api from "../utils/localhost8080Api";

const TableRow = ({id,firstname,lastname,email,personalNo,birthDate,wholeStud,func}) => {
    //const Navigate= useNavigate();
    const changeFunc = () => {
        func(wholeStud);
    }

    const deleteStudent = () => {
        console.log(id);
        api.delete(`/students/${id}`);
        document.location.reload()
    }

    return (
        <tr>
            <td>{id}</td>
            <td>{firstname}</td>
            <td>{lastname}</td>
            <td>{personalNo}</td>
            <td>{email}</td>
            <td>{birthDate}</td>
            <td>
                <Button variant="primary" className="me-2" onClick={changeFunc}>Change</Button>
                <Button type="submit" variant="danger" className="m-0" onClick={deleteStudent}>Delete</Button>
            </td>
        </tr>
    )
}

function StudentsList({data,func,title}) {

    return (
        <>
            <h1>{title}</h1>
            <Table striped bordered hover>
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Personal_no</th>
                    <th>Email</th>
                    <th>Birth_date</th>
                    <th>Change/Delete</th>
                </tr>
                </thead>
                <tbody>
                {
                    data.map(student=>
                        <TableRow key={student.id}
                                  {...student} wholeStud={student} func={func}/>
                    )
                }
                </tbody>
            </Table>
        </>
    );

}

export default StudentsList;