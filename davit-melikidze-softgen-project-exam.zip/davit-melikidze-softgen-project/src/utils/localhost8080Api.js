import axios from 'axios';

const api = axios.create({
    // baseURL: 'http://localhost:8080/',
    timeout: 5 * 1000
})

api.interceptors.request.use(function (config) {
    // Do something before request is sent
    config.headers['X-SOFTLAB'] ='softlab'
    return config;
});

api.interceptors.response.use(function (response) {
    console.log(response.data);
    return response;
}, function (error) {
    if(error.response.status>=400){
        console.error('Response Error',error);
        alert(error.response.status);
    }
    return Promise.reject(error);
});

export default api;