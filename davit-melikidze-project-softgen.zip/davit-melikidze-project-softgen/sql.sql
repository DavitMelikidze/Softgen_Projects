create table if not exists students
(
    id          serial
    constraint students_pk
    primary key,
    firstname   text,
    lastname    text,
    personal_no text,
    email       text,
    birth_date  date default now()
    );

alter table students
    owner to postgres;

create table if not exists teachers
(
    id          serial
    constraint teachers_pk
    primary key,
    firstname   text,
    lastname    text,
    personal_no text,
    email       text,
    birth_date  date default now()
    );

alter table teachers
    owner to postgres;

