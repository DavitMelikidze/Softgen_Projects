package com.example.davitmelikidzeprojectsoftgen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DavitMelikidzeProjectSoftgenApplicationTests {

    @Test
    void contextLoads() {
    }

}
