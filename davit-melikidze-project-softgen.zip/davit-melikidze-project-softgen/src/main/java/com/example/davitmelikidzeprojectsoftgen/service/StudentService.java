package com.example.davitmelikidzeprojectsoftgen.service;

import com.example.davitmelikidzeprojectsoftgen.controller.StudentController;
import com.example.davitmelikidzeprojectsoftgen.model.Student;

import java.util.List;

public interface StudentService {

    List<Student> getStudents(StudentController.StudentSearch studentSearch);

    Student get(Integer id) throws Exception;

    Student add(Student student);

    void delete(Integer id) throws Exception;

    Student update(Student student) throws Exception;
}
