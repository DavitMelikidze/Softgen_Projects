package com.example.davitmelikidzeprojectsoftgen.controller;

import com.example.davitmelikidzeprojectsoftgen.model.Student;
import com.example.davitmelikidzeprojectsoftgen.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("students")
public class StudentController {

    private final StudentService studentService;

    public static record StudentSearch(String firstName, String lastName, String personalNo, String email){}

    @GetMapping
    public List<Student> getStudents(StudentSearch studentSearch){
        return studentService.getStudents(studentSearch);
    }

    @GetMapping("{id}")
    public ResponseEntity<Student> getStudent(@PathVariable Integer id){
        try{
            return ResponseEntity.ok(studentService.get(id));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Student> addNewStudent(@RequestBody Student student){
        return ResponseEntity.status(201).body(studentService.add(student));
    }

    @DeleteMapping("{id}")
    public void deleteStudent(@PathVariable Integer id) throws Exception {
        studentService.delete(id);
    }

    @PutMapping("{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Integer id, @RequestBody Student student){
        try {
            student.setId(id);
            Student dbStudent = studentService.update(student);
            return ResponseEntity.ok(dbStudent);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

}
