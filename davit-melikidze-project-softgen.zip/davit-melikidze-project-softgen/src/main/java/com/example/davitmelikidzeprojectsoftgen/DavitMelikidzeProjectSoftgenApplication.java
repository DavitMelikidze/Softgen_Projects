package com.example.davitmelikidzeprojectsoftgen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DavitMelikidzeProjectSoftgenApplication {

    public static void main(String[] args) {
        SpringApplication.run(DavitMelikidzeProjectSoftgenApplication.class, args);
    }

}
