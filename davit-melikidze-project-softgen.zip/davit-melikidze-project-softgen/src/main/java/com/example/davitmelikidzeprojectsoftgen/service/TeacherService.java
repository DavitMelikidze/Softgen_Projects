package com.example.davitmelikidzeprojectsoftgen.service;

import com.example.davitmelikidzeprojectsoftgen.controller.StudentController;
import com.example.davitmelikidzeprojectsoftgen.controller.TeacherController;
import com.example.davitmelikidzeprojectsoftgen.model.Student;
import com.example.davitmelikidzeprojectsoftgen.model.Teacher;

import java.util.List;

public interface TeacherService {
    List<Teacher> getTeachers(TeacherController.TeacherSearch teacherSearch);

    Teacher get(Integer id) throws Exception;

    Teacher add(Teacher teacher);

    void delete(Integer id) throws Exception;

    Teacher update(Teacher teacher) throws Exception;
}
