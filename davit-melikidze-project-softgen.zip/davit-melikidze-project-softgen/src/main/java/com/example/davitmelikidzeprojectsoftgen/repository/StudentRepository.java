package com.example.davitmelikidzeprojectsoftgen.repository;

import com.example.davitmelikidzeprojectsoftgen.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.expression.spel.support.ReflectivePropertyAccessor;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student,Integer> {

    //Optional<Student> findById(Integer id);

    List<Student> findByFirstname(String firstname);

    List<Student> findByLastname(String lastname);

    List<Student> findByEmail(String email);

    List<Student> findByPersonalNo(String personalNo);

}
