package com.example.davitmelikidzeprojectsoftgen.service;

import com.example.davitmelikidzeprojectsoftgen.controller.StudentController;
import com.example.davitmelikidzeprojectsoftgen.controller.TeacherController;
import com.example.davitmelikidzeprojectsoftgen.model.Student;
import com.example.davitmelikidzeprojectsoftgen.model.Teacher;
import com.example.davitmelikidzeprojectsoftgen.repository.StudentRepository;
import com.example.davitmelikidzeprojectsoftgen.repository.TeacherRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TeacherServiceImpl implements TeacherService{
    private final TeacherRepository teacherRepository;

    @Override
    public List<Teacher> getTeachers(TeacherController.TeacherSearch teacherSearch) {
        if(teacherSearch.firstName()!=null){
            return teacherRepository.findByFirstname(teacherSearch.firstName());
        }
        if(teacherSearch.lastName()!=null){
            return teacherRepository.findByLastname(teacherSearch.lastName());
        }
        if(teacherSearch.email()!=null){
            return teacherRepository.findByEmail(teacherSearch.email());
        }
        if(teacherSearch.personalNo()!=null){
            return teacherRepository.findByPersonalNo(teacherSearch.personalNo());
        }
        return teacherRepository.findAll();
    }

    @Override
    public Teacher get(Integer id) throws Exception {
        return teacherRepository.findById(id).orElseThrow(() -> new Exception("Student not found"));
    }

    @Override
    public Teacher add(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    @Override
    public void delete(Integer id) throws Exception {
        Teacher S = get(id);
        teacherRepository.delete(S);
    }

    @Override
    public Teacher update(Teacher teacher) throws Exception {
        Teacher S = get(teacher.getId());
        return teacherRepository.save(teacher);
    }
}
