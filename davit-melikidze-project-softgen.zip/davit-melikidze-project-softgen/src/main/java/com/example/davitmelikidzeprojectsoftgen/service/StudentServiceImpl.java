package com.example.davitmelikidzeprojectsoftgen.service;

import com.example.davitmelikidzeprojectsoftgen.controller.StudentController;
import com.example.davitmelikidzeprojectsoftgen.model.Student;
import com.example.davitmelikidzeprojectsoftgen.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {
    private final StudentRepository studentRepository;

    @Override
    public List<Student> getStudents(StudentController.StudentSearch studentSearch) {
        if(studentSearch.firstName()!=null){
            return studentRepository.findByFirstname(studentSearch.firstName());
        }
        if(studentSearch.lastName()!=null){
            return studentRepository.findByLastname(studentSearch.lastName());
        }
        if(studentSearch.email()!=null){
            return studentRepository.findByEmail(studentSearch.email());
        }
        if(studentSearch.personalNo()!=null){
            return studentRepository.findByPersonalNo(studentSearch.personalNo());
        }
        return studentRepository.findAll();
    }

    @Override
    public Student get(Integer id) throws Exception {
        return studentRepository.findById(id).orElseThrow(() -> new Exception("Student not found"));
    }

    @Override
    public Student add(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public void delete(Integer id) throws Exception {
        Student S = get(id);
        studentRepository.delete(S);
    }

    @Override
    public Student update(Student student) throws Exception {
        Student S = get(student.getId());
        return studentRepository.save(student);
    }
}
