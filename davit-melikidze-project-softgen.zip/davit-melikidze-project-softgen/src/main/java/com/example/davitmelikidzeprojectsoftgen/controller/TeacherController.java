package com.example.davitmelikidzeprojectsoftgen.controller;

import com.example.davitmelikidzeprojectsoftgen.model.Student;
import com.example.davitmelikidzeprojectsoftgen.model.Teacher;
import com.example.davitmelikidzeprojectsoftgen.service.StudentService;
import com.example.davitmelikidzeprojectsoftgen.service.TeacherService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("teachers")
public class TeacherController {

    private final TeacherService teacherService;

    public static record TeacherSearch(String firstName, String lastName, String personalNo, String email){}

    @GetMapping
    public List<Teacher> getProducts(TeacherSearch teacherSearch){
        return teacherService.getTeachers(teacherSearch);
    }

    @GetMapping("{id}")
    public ResponseEntity<Teacher> getTeacher(@PathVariable Integer id){
        try{
            return ResponseEntity.ok(teacherService.get(id));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Teacher> addNewTeacher(@RequestBody Teacher teacher){
        return ResponseEntity.status(201).body(teacherService.add(teacher));
    }

    @DeleteMapping("{id}")
    public void deleteTeacher(@PathVariable Integer id) throws Exception {
        teacherService.delete(id);
    }

    @PutMapping("{id}")
    public ResponseEntity<Teacher> updateTeacher(@PathVariable Integer id, @RequestBody Teacher teacher){
        try {
            teacher.setId(id);
            Teacher dbTeacher = teacherService.update(teacher);
            return ResponseEntity.ok(dbTeacher);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

}
