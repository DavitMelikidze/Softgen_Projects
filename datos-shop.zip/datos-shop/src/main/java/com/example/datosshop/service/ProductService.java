package com.example.datosshop.service;

import com.example.datosshop.controller.ProductController;
import com.example.datosshop.model.Product;
import com.example.datosshop.model.Purchase;

import java.util.List;
import java.util.Optional;

public interface ProductService {

    List<Product> getProducts(ProductController.ProductSearch productSearch);

    Product get(String id) throws Exception;

    Product add(Product product);

    void sell(String id) throws Exception;

    Purchase purchase(String id, Integer count) throws Exception;
}
