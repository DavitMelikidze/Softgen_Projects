package com.example.datosshop.repository;

import com.example.datosshop.model.Product;
import com.example.datosshop.model.Sale;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface SaleRepository extends JpaRepository<Sale,Integer> {
    List<Sale> findBySellDate(LocalDate date);
}
