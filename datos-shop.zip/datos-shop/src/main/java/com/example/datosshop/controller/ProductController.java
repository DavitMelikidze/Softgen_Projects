package com.example.datosshop.controller;

import com.example.datosshop.model.Product;
import com.example.datosshop.model.Purchase;
import com.example.datosshop.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("products")
public class ProductController {
    private final ProductService productService;

    public static record ProductSearch(String productName, Integer makerId, Integer categoryId){}

    @GetMapping
    public List<Product> getProducts(ProductSearch productSearch){
        return productService.getProducts(productSearch);
    }

    @GetMapping("{id}")
    public ResponseEntity<Product> getProduct(@PathVariable String id){
        try{
            return ResponseEntity.ok(productService.get(id));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Product> addNewProduct(@RequestBody Product product){
        return ResponseEntity.status(201).body(productService.add(product));
    }

    @GetMapping("{id}/sales")
    public ResponseEntity<Void> sellProduct(@PathVariable String id){
        try {
            productService.sell(id);
            return ResponseEntity.status(201).build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("{id}/purchases")
    public ResponseEntity<Purchase> purchaseProduct(@PathVariable String id,@RequestBody String count) throws Exception {
        return ResponseEntity.status(201).body(productService.purchase(id, Integer.valueOf(count)));
    }
}
