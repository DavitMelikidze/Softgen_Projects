package com.example.datosshop.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "categories")
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    public Category(Integer id, Category parent, String categoryName) {
        this.id = id;
        this.parent = parent;
        this.categoryName = categoryName;
    }

    @ManyToOne(optional = false)
    @JoinColumn(name = "parent_id", nullable = true)
    private Category parent;

    @Column(name = "category_name", nullable = false)
    private String categoryName;
}