package com.example.datosshop.service;

import com.example.datosshop.controller.ProductController;
import com.example.datosshop.model.Product;
import com.example.datosshop.model.Purchase;
import com.example.datosshop.model.Sale;
import com.example.datosshop.repository.ProductRepository;
import com.example.datosshop.repository.PurchaseRepository;
import com.example.datosshop.repository.SaleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService{
    private final ProductRepository productRepository;
    private final SaleRepository saleRepository;
    private final PurchaseRepository purchaseRepository;

    public List<Product> getProducts(ProductController.ProductSearch productSearch){
        if(productSearch.productName()!=null){
            return productRepository.findByProductName(productSearch.productName());
        }
        if(productSearch.makerId()!=null){
            return productRepository.findByMakerId(productSearch.makerId());
        }
        if(productSearch.categoryId()!=null){
            return productRepository.findByCategoryId(productSearch.categoryId());
        }
        return productRepository.findAll();
    }

    public Product getProduct(String id) throws Exception {
        return get(id);
    }

    public Product get(String id) throws Exception{
        return productRepository.findById(id).orElseThrow(() -> new Exception("Product not found"));
    }

    public Product add(Product product){
        return productRepository.save(product);
    }

    public void sell(String id) throws Exception {
        Product P = get(id);
        if(P.getRemaining()==0)throw new Exception();
        P.setRemaining(P.getRemaining()-1);
        productRepository.save(P);
        Sale S = new Sale(P,P.getSellPrice());
        saleRepository.save(S);
    }

    public Purchase purchase(String id, Integer count) throws Exception {
        Product P = get(id);
        P.setRemaining(P.getRemaining()+count);
        productRepository.save(P);
        BigDecimal Percent = new BigDecimal(0.9);
        Purchase Pr = new Purchase(P.getId(),P.getSellPrice().multiply(Percent));
        return purchaseRepository.save(Pr);
    }

}
