package com.example.datosshop.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "makers")
public class Maker {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    public Maker(Integer id, String makerName) {
        this.id = id;
        this.makerName = makerName;
    }

    @Column(name = "maker_name", nullable = false)
    private String makerName;

}