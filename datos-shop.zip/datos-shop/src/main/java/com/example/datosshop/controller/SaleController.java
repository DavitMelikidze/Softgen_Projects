package com.example.datosshop.controller;

import com.example.datosshop.model.Sale;
import com.example.datosshop.service.SaleService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class SaleController {
    private final SaleService saleService;
    @PostMapping("sales")
    List<Sale> getSale(@RequestBody String date){
        return saleService.getSale(date);
    }
}
