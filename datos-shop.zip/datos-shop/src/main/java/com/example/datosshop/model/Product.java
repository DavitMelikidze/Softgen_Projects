package com.example.datosshop.model;

import com.example.datosshop.model.Category;
import com.example.datosshop.model.Maker;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "products")
public class Product {
    @Id
    @Column(name = "ean_code", nullable = false)
    private String id;

    @Column(name = "product_name", nullable = false)
    private String productName;

    @Column(name = "description", nullable = false)
    private String description;

    public Product(String id, String productName, String description, Maker maker, Category category, BigDecimal sellPrice, Integer remaining) {
        this.id = id;
        this.productName = productName;
        this.description = description;
        this.maker = maker;
        this.category = category;
        this.sellPrice = sellPrice;
        this.remaining = remaining;
    }

    @ManyToOne(optional = false, cascade = CascadeType.ALL)
    @JoinColumn(name = "maker_id", nullable = false)
    private Maker maker;

    @ManyToOne(optional = false)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @Column(name = "sell_price", nullable = false, precision = 10, scale = 2)
    private BigDecimal sellPrice;

    @Column(name = "remaining", nullable = false)
    private Integer remaining;
}
