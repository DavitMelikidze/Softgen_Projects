package com.example.datosshop.service;

import com.example.datosshop.model.Sale;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface SaleService {
    List<Sale> getSale(String date);
}
